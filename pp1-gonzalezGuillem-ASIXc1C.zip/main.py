import utilities

def main():
    utilities.showmenu()
    utilities.optionget()


main()
